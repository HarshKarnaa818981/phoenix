module traffic_4way (
    input clk,          // 1 Hz clock
    input reset,

    // North signals
    output reg N_green, N_yellow, N_red,
    // East signals
    output reg E_green, E_yellow, E_red,
    // South signals
    output reg S_green, S_yellow, S_red,
    // West signals
    output reg W_green, W_yellow, W_red
);

    // States for each phase
    parameter N_G = 3'd0, N_Y = 3'd1,
              E_G = 3'd2, E_Y = 3'd3,
              S_G = 3'd4, S_Y = 3'd5,
              W_G = 3'd6, W_Y = 3'd7;

    reg [2:0] state;
    reg [5:0] counter; // max 30 sec needed

    // State transition
    always @(posedge clk) begin
        if (reset) begin
            state <= N_G;
            counter <= 0;
        end else begin
            case (state)
                N_G: if (counter < 29) counter <= counter + 1;
                     else begin state <= N_Y; counter <= 0; end

                N_Y: if (counter < 4) counter <= counter + 1;
                     else begin state <= E_G; counter <= 0; end

                E_G: if (counter < 29) counter <= counter + 1;
                     else begin state <= E_Y; counter <= 0; end

                E_Y: if (counter < 4) counter <= counter + 1;
                     else begin state <= S_G; counter <= 0; end

                S_G: if (counter < 29) counter <= counter + 1;
                     else begin state <= S_Y; counter <= 0; end

                S_Y: if (counter < 4) counter <= counter + 1;
                     else begin state <= W_G; counter <= 0; end

                W_G: if (counter < 29) counter <= counter + 1;
                     else begin state <= W_Y; counter <= 0; end

                W_Y: if (counter < 4) counter <= counter + 1;
                     else begin state <= N_G; counter <= 0; end

                default: begin state <= N_G; counter <= 0; end
            endcase
        end
    end

    // Output logic
    always @(*) begin
        // Default: all RED
        N_green=0; N_yellow=0; N_red=1;
        E_green=0; E_yellow=0; E_red=1;
        S_green=0; S_yellow=0; S_red=1;
        W_green=0; W_yellow=0; W_red=1;

        case (state)
            N_G: begin N_green=1; N_red=0; end
            N_Y: begin N_yellow=1; N_red=0; end

            E_G: begin E_green=1; E_red=0; end
            E_Y: begin E_yellow=1; E_red=0; end

            S_G: begin S_green=1; S_red=0; end
            S_Y: begin S_yellow=1; S_red=0; end

            W_G: begin W_green=1; W_red=0; end
            W_Y: begin W_yellow=1; W_red=0; end
        endcase
    end

endmodule