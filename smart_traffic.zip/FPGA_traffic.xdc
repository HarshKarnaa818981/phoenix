##---------------- CLOCK ----------------
set_property PACKAGE_PIN E3 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk]
create_clock -period 10.000 -name sys_clk_pin [get_ports clk]

##---------------- RESET BUTTON ----------------
set_property PACKAGE_PIN D9 [get_ports reset]
set_property IOSTANDARD LVCMOS33 [get_ports reset]

##---------------- MAIN INPUT SWITCHES ----------------
set_property PACKAGE_PIN A8 [get_ports emergency]
set_property IOSTANDARD LVCMOS33 [get_ports emergency]

set_property PACKAGE_PIN C11 [get_ports pedestrian]
set_property IOSTANDARD LVCMOS33 [get_ports pedestrian]

set_property PACKAGE_PIN C10 [get_ports fault]
set_property IOSTANDARD LVCMOS33 [get_ports fault]

##---------------- EMERGENCY DIRECTION INPUTS ----------------
set_property PACKAGE_PIN A10 [get_ports emg_n]
set_property IOSTANDARD LVCMOS33 [get_ports emg_n]

set_property PACKAGE_PIN A9 [get_ports emg_s]
set_property IOSTANDARD LVCMOS33 [get_ports emg_s]

set_property PACKAGE_PIN B9 [get_ports emg_e]
set_property IOSTANDARD LVCMOS33 [get_ports emg_e]

set_property PACKAGE_PIN B8 [get_ports emg_w]
set_property IOSTANDARD LVCMOS33 [get_ports emg_w]

##---------------- TRAFFIC REQUEST INPUTS ----------------
set_property PACKAGE_PIN G13 [get_ports dir_n]
set_property IOSTANDARD LVCMOS33 [get_ports dir_n]

set_property PACKAGE_PIN B11 [get_ports dir_s]
set_property IOSTANDARD LVCMOS33 [get_ports dir_s]

set_property PACKAGE_PIN A11 [get_ports dir_e]
set_property IOSTANDARD LVCMOS33 [get_ports dir_e]

set_property PACKAGE_PIN D12 [get_ports dir_w]
set_property IOSTANDARD LVCMOS33 [get_ports dir_w]

##==============================================================
## OUTPUT LEDs
##==============================================================

## NORTH
set_property PACKAGE_PIN H5 [get_ports {north[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {north[0]}]

set_property PACKAGE_PIN J5 [get_ports {north[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {north[1]}]

set_property PACKAGE_PIN T9 [get_ports {north[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {north[2]}]

## SOUTH
set_property PACKAGE_PIN T10 [get_ports {south[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {south[0]}]

set_property PACKAGE_PIN T11 [get_ports {south[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {south[1]}]

set_property PACKAGE_PIN U12 [get_ports {south[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {south[2]}]

## EAST
set_property PACKAGE_PIN V11 [get_ports {east[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {east[0]}]

set_property PACKAGE_PIN V10 [get_ports {east[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {east[1]}]

set_property PACKAGE_PIN U9 [get_ports {east[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {east[2]}]

## WEST
set_property PACKAGE_PIN T8 [get_ports {west[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {west[0]}]

set_property PACKAGE_PIN U8 [get_ports {west[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {west[1]}]

set_property PACKAGE_PIN V16 [get_ports {west[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {west[2]}]

##---------------- STATUS OUTPUTS ----------------
set_property PACKAGE_PIN U16 [get_ports ped_walk]
set_property IOSTANDARD LVCMOS33 [get_ports ped_walk]

set_property PACKAGE_PIN R12 [get_ports fault_alert]
set_property IOSTANDARD LVCMOS33 [get_ports fault_alert]