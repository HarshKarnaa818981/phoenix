`timescale 1ns / 1ps

module tb_smart_traffic_final;

reg clk;
reg reset;

reg dir_n;
reg dir_s;
reg dir_e;
reg dir_w;

reg emergency;
reg emg_n;
reg emg_s;
reg emg_e;
reg emg_w;

reg pedestrian;
reg fault;

wire [2:0] north;
wire [2:0] south;
wire [2:0] east;
wire [2:0] west;

wire ped_walk;
wire fault_alert;


// DUT Instantiation
smart_traffic_final uut (

.clk(clk),
.reset(reset),

.dir_n(dir_n),
.dir_s(dir_s),
.dir_e(dir_e),
.dir_w(dir_w),

.emergency(emergency),
.emg_n(emg_n),
.emg_s(emg_s),
.emg_e(emg_e),
.emg_w(emg_w),

.pedestrian(pedestrian),
.fault(fault),

.north(north),
.south(south),
.east(east),
.west(west),

.ped_walk(ped_walk),
.fault_alert(fault_alert)

);


// Clock Generation (10ns period)
always #5 clk = ~clk;


initial
begin

clk = 0;
reset = 1;

dir_n = 0;
dir_s = 0;
dir_e = 0;
dir_w = 0;

emergency = 0;
emg_n = 0;
emg_s = 0;
emg_e = 0;
emg_w = 0;

pedestrian = 0;
fault = 0;


// Reset
#20;
reset = 0;


// ---------------- NORMAL TRAFFIC ----------------
dir_n = 1;
dir_e = 1;
#2500;


// ---------------- EMERGENCY NORTH ----------------
emergency = 1;
emg_n = 1;
#500;
emergency = 0;
emg_n = 0;

#500;


// ---------------- EMERGENCY SOUTH ----------------
emergency = 1;
emg_s = 1;
#500;
emergency = 0;
emg_s = 0;

#500;


// ---------------- EMERGENCY EAST ----------------
emergency = 1;
emg_e = 1;
#500;
emergency = 0;
emg_e = 0;

#500;


// ---------------- EMERGENCY WEST ----------------
emergency = 1;
emg_w = 1;
#500;
emergency = 0;
emg_w = 0;

#1000;


// ---------------- PEDESTRIAN ----------------
pedestrian = 1;
#800;
pedestrian = 0;

#1000;


// ---------------- FAULT MODE ----------------
fault = 1;
#800;
fault = 0;

#1500;


$finish;

end

endmodule