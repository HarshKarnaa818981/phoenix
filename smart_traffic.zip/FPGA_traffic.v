`timescale 1ns / 1ps

module smart_traffic_final(

input clk,
input reset,

input dir_n,
input dir_s,
input dir_e,
input dir_w,

input emergency,
input emg_n,
input emg_s,
input emg_e,
input emg_w,

input pedestrian,
input fault,

output reg [2:0] north,
output reg [2:0] south,
output reg [2:0] east,
output reg [2:0] west,

output reg ped_walk,
output reg fault_alert

);

reg [3:0] state;
reg [8:0] count;

parameter N   = 4'd0,
          NY  = 4'd1,
          E   = 4'd2,
          EY  = 4'd3,
          S   = 4'd4,
          SY  = 4'd5,
          W   = 4'd6,
          WY  = 4'd7,
          PED = 4'd8,
          EMR = 4'd9,
          FLT = 4'd10;

always @(posedge clk or posedge reset)
begin
    if(reset)
    begin
        state <= N;
        count <= 0;
    end
    else
    begin

        // Priority Logic
        if(fault)
        begin
            state <= FLT;
            count <= 0;
        end

        else if(emergency)
        begin
            state <= EMR;
            count <= 0;
        end

        else if(pedestrian)
        begin
            state <= PED;
            count <= 0;
        end

        else
        begin
            count <= count + 1;

            case(state)

            N  : if(count==150) begin state<=NY; count<=0; end
            NY : if(count==50)  begin state<=E;  count<=0; end

            E  : if(count==150) begin state<=EY; count<=0; end
            EY : if(count==50)  begin state<=S;  count<=0; end

            S  : if(count==150) begin state<=SY; count<=0; end
            SY : if(count==50)  begin state<=W;  count<=0; end

            W  : if(count==150) begin state<=WY; count<=0; end
            WY : if(count==50)  begin state<=N;  count<=0; end

            PED : if(count==100) begin state<=N; count<=0; end
            EMR : if(count==100) begin state<=N; count<=0; end
            FLT : if(count==100) begin state<=N; count<=0; end

            default : begin
                state <= N;
                count <= 0;
            end

            endcase
        end
    end
end


always @(*)
begin

// Default Outputs
north = 3'b100;
south = 3'b100;
east  = 3'b100;
west  = 3'b100;

ped_walk = 0;
fault_alert = 0;

case(state)

// ---------------- NORMAL TRAFFIC ----------------
N  : north = 3'b001;
NY : north = 3'b010;

E  : east  = 3'b001;
EY : east  = 3'b010;

S  : south = 3'b001;
SY : south = 3'b010;

W  : west  = 3'b001;
WY : west  = 3'b010;


// ---------------- PEDESTRIAN MODE ----------------
PED :
begin
    north = 3'b100;
    south = 3'b100;
    east  = 3'b100;
    west  = 3'b100;

    ped_walk = 1;
end


// ---------------- EMERGENCY MODE ----------------
EMR :
begin
    north = 3'b100;
    south = 3'b100;
    east  = 3'b100;
    west  = 3'b100;

    if(emg_n)
        north = 3'b001;
    else if(emg_s)
        south = 3'b001;
    else if(emg_e)
        east = 3'b001;
    else if(emg_w)
        west = 3'b001;
end


// ---------------- FAULT MODE ----------------
FLT :
begin
    north = 3'b010;
    south = 3'b010;
    east  = 3'b010;
    west  = 3'b010;

    fault_alert = 1;
end

endcase

end

endmodule