`timescale 1ns/1ps

module tb_traffic_4way;

    reg clk;
    reg reset;

    // Outputs from DUT
    wire N_green, N_yellow, N_red;
    wire E_green, E_yellow, E_red;
    wire S_green, S_yellow, S_red;
    wire W_green, W_yellow, W_red;

    // Instantiate DUT
    traffic_4way uut (
        .clk(clk),
        .reset(reset),

        .N_green(N_green), .N_yellow(N_yellow), .N_red(N_red),
        .E_green(E_green), .E_yellow(E_yellow), .E_red(E_red),
        .S_green(S_green), .S_yellow(S_yellow), .S_red(S_red),
        .W_green(W_green), .W_yellow(W_yellow), .W_red(W_red)
    );

    // Clock generation (10ns period)
    always #5 clk = ~clk;

    initial begin
        // Initialize
        clk = 0;
        reset = 1;

        // Apply reset
        #20;
        reset = 0;

        // Run simulation long enough (full cycle ≈ 140 cycles)
        #2000;

        $stop;
    end

    // Monitor all signals
    initial begin
        $monitor("Time=%0t | N(G,Y,R)=%b%b%b | E=%b%b%b | S=%b%b%b | W=%b%b%b",
                 $time,
                 N_green, N_yellow, N_red,
                 E_green, E_yellow, E_red,
                 S_green, S_yellow, S_red,
                 W_green, W_yellow, W_red);
    end

endmodule